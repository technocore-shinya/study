package com.example.entity;

/** */
@javax.annotation.Generated(value = { "Doma", "1.38.0" }, date = "2019-04-06T13:03:23.739+0900")
public final class _Department extends org.seasar.doma.jdbc.entity.AbstractEntityType<com.example.entity.Department> {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("1.38.0");
    }

    private static final _Department __singleton = new _Department();

    /** the ID */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.Department, java.lang.Integer, java.lang.Object> $ID = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.Department, java.lang.Integer, java.lang.Object>(com.example.entity.Department.class, java.lang.Integer.class, org.seasar.doma.wrapper.IntegerWrapper.class, null, null, "ID", "ID", true, true);

    /** the DepartmentName */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.Department, java.lang.String, java.lang.Object> $DepartmentName = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.Department, java.lang.String, java.lang.Object>(com.example.entity.Department.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "DepartmentName", "DepartmentName", true, true);

    private final org.seasar.doma.jdbc.entity.NullEntityListener<com.example.entity.Department> __listener;

    private final org.seasar.doma.jdbc.entity.NamingType __namingType;

    private final boolean __immutable;

    private final String __catalogName;

    private final String __schemaName;

    private final String __tableName;

    private final String __qualifiedTableName;

    private final String __name;

    private final java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> __idPropertyTypes;

    private final java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> __entityPropertyTypes;

    private final java.util.Map<String, org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> __entityPropertyTypeMap;

    private _Department() {
        __listener = new org.seasar.doma.jdbc.entity.NullEntityListener<com.example.entity.Department>();
        __namingType = org.seasar.doma.jdbc.entity.NamingType.NONE;
        __immutable = false;
        __name = "Department";
        __catalogName = "";
        __schemaName = "";
        __tableName = "Department";
        __qualifiedTableName = "Department";
        java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> __idList = new java.util.ArrayList<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>>();
        java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> __list = new java.util.ArrayList<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>>(2);
        java.util.Map<String, org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> __map = new java.util.HashMap<String, org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>>(2);
        __list.add($ID);
        __map.put("ID", $ID);
        __list.add($DepartmentName);
        __map.put("DepartmentName", $DepartmentName);
        __idPropertyTypes = java.util.Collections.unmodifiableList(__idList);
        __entityPropertyTypes = java.util.Collections.unmodifiableList(__list);
        __entityPropertyTypeMap = java.util.Collections.unmodifiableMap(__map);
    }

    @Override
    public org.seasar.doma.jdbc.entity.NamingType getNamingType() {
        return __namingType;
    }

    @Override
    public boolean isImmutable() {
        return __immutable;
    }

    @Override
    public String getName() {
        return __name;
    }

    @Override
    public String getCatalogName() {
        return __catalogName;
    }

    @Override
    public String getSchemaName() {
        return __schemaName;
    }

    @Override
    public String getTableName() {
        return __tableName;
    }

    @Override
    public String getQualifiedTableName() {
        return __qualifiedTableName;
    }

    @Override
    public void preInsert(com.example.entity.Department entity, org.seasar.doma.jdbc.entity.PreInsertContext<com.example.entity.Department> context) {
        __listener.preInsert(entity, context);
    }

    @Override
    public void preUpdate(com.example.entity.Department entity, org.seasar.doma.jdbc.entity.PreUpdateContext<com.example.entity.Department> context) {
        __listener.preUpdate(entity, context);
    }

    @Override
    public void preDelete(com.example.entity.Department entity, org.seasar.doma.jdbc.entity.PreDeleteContext<com.example.entity.Department> context) {
        __listener.preDelete(entity, context);
    }

    @Override
    public void postInsert(com.example.entity.Department entity, org.seasar.doma.jdbc.entity.PostInsertContext<com.example.entity.Department> context) {
        __listener.postInsert(entity, context);
    }

    @Override
    public void postUpdate(com.example.entity.Department entity, org.seasar.doma.jdbc.entity.PostUpdateContext<com.example.entity.Department> context) {
        __listener.postUpdate(entity, context);
    }

    @Override
    public void postDelete(com.example.entity.Department entity, org.seasar.doma.jdbc.entity.PostDeleteContext<com.example.entity.Department> context) {
        __listener.postDelete(entity, context);
    }

    @Override
    public java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> getEntityPropertyTypes() {
        return __entityPropertyTypes;
    }

    @Override
    public org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?> getEntityPropertyType(String __name) {
        return __entityPropertyTypeMap.get(__name);
    }

    @Override
    public java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.Department, ?>> getIdPropertyTypes() {
        return __idPropertyTypes;
    }

    @Override
    public org.seasar.doma.jdbc.entity.GeneratedIdPropertyType<java.lang.Object, com.example.entity.Department, ?, ?> getGeneratedIdPropertyType() {
        return null;
    }

    @Override
    public org.seasar.doma.jdbc.entity.VersionPropertyType<java.lang.Object, com.example.entity.Department, ?, ?> getVersionPropertyType() {
        return null;
    }

    @Override
    public com.example.entity.Department newEntity() {
        return new com.example.entity.Department();
    }

    @Override
    public com.example.entity.Department newEntity(java.util.Map<String, Object> __args) {
        return new com.example.entity.Department();
    }

    @Override
    public Class<com.example.entity.Department> getEntityClass() {
        return com.example.entity.Department.class;
    }

    @Override
    public com.example.entity.Department getOriginalStates(com.example.entity.Department __entity) {
        return null;
    }

    @Override
    public void saveCurrentStates(com.example.entity.Department __entity) {
    }

    /**
     * @return the singleton
     */
    public static _Department getSingletonInternal() {
        return __singleton;
    }

    /**
     * @return the new instance
     */
    public static _Department newInstance() {
        return new _Department();
    }

}
