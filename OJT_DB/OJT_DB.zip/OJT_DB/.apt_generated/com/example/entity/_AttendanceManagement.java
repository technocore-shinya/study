package com.example.entity;

/** */
@javax.annotation.Generated(value = { "Doma", "1.38.0" }, date = "2019-04-06T13:03:23.802+0900")
public final class _AttendanceManagement extends org.seasar.doma.jdbc.entity.AbstractEntityType<com.example.entity.AttendanceManagement> {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("1.38.0");
    }

    private static final _AttendanceManagement __singleton = new _AttendanceManagement();

    /** the ID */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.Integer, java.lang.Object> $ID = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.Integer, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.Integer.class, org.seasar.doma.wrapper.IntegerWrapper.class, null, null, "ID", "ID", true, true);

    /** the employeeID */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.Integer, java.lang.Object> $employeeID = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.Integer, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.Integer.class, org.seasar.doma.wrapper.IntegerWrapper.class, null, null, "employeeID", "employeeID", true, true);

    /** the workingStartTime */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object> $workingStartTime = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "workingStartTime", "workingStartTime", true, true);

    /** the workingEndTime */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object> $workingEndTime = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "workingEndTime", "workingEndTime", true, true);

    /** the regName */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object> $regName = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "regName", "regName", true, true);

    /** the regDate */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object> $regDate = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "regDate", "regDate", true, true);

    /** the updName */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object> $updName = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "updName", "updName", true, true);

    /** the updDate */
    public final org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object> $updDate = new org.seasar.doma.jdbc.entity.BasicPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.String, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.String.class, org.seasar.doma.wrapper.StringWrapper.class, null, null, "updDate", "updDate", true, true);

    /** the version */
    public final org.seasar.doma.jdbc.entity.VersionPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.Integer, java.lang.Object> $version = new org.seasar.doma.jdbc.entity.VersionPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, java.lang.Integer, java.lang.Object>(com.example.entity.AttendanceManagement.class, java.lang.Integer.class, org.seasar.doma.wrapper.IntegerWrapper.class, null, null, "version", "version");

    private final org.seasar.doma.jdbc.entity.NullEntityListener<com.example.entity.AttendanceManagement> __listener;

    private final org.seasar.doma.jdbc.entity.NamingType __namingType;

    private final boolean __immutable;

    private final String __catalogName;

    private final String __schemaName;

    private final String __tableName;

    private final String __qualifiedTableName;

    private final String __name;

    private final java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> __idPropertyTypes;

    private final java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> __entityPropertyTypes;

    private final java.util.Map<String, org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> __entityPropertyTypeMap;

    private _AttendanceManagement() {
        __listener = new org.seasar.doma.jdbc.entity.NullEntityListener<com.example.entity.AttendanceManagement>();
        __namingType = org.seasar.doma.jdbc.entity.NamingType.NONE;
        __immutable = false;
        __name = "AttendanceManagement";
        __catalogName = "";
        __schemaName = "";
        __tableName = "AttendanceManagement";
        __qualifiedTableName = "AttendanceManagement";
        java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> __idList = new java.util.ArrayList<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>>();
        java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> __list = new java.util.ArrayList<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>>(9);
        java.util.Map<String, org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> __map = new java.util.HashMap<String, org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>>(9);
        __list.add($ID);
        __map.put("ID", $ID);
        __list.add($employeeID);
        __map.put("employeeID", $employeeID);
        __list.add($workingStartTime);
        __map.put("workingStartTime", $workingStartTime);
        __list.add($workingEndTime);
        __map.put("workingEndTime", $workingEndTime);
        __list.add($regName);
        __map.put("regName", $regName);
        __list.add($regDate);
        __map.put("regDate", $regDate);
        __list.add($updName);
        __map.put("updName", $updName);
        __list.add($updDate);
        __map.put("updDate", $updDate);
        __list.add($version);
        __map.put("version", $version);
        __idPropertyTypes = java.util.Collections.unmodifiableList(__idList);
        __entityPropertyTypes = java.util.Collections.unmodifiableList(__list);
        __entityPropertyTypeMap = java.util.Collections.unmodifiableMap(__map);
    }

    @Override
    public org.seasar.doma.jdbc.entity.NamingType getNamingType() {
        return __namingType;
    }

    @Override
    public boolean isImmutable() {
        return __immutable;
    }

    @Override
    public String getName() {
        return __name;
    }

    @Override
    public String getCatalogName() {
        return __catalogName;
    }

    @Override
    public String getSchemaName() {
        return __schemaName;
    }

    @Override
    public String getTableName() {
        return __tableName;
    }

    @Override
    public String getQualifiedTableName() {
        return __qualifiedTableName;
    }

    @Override
    public void preInsert(com.example.entity.AttendanceManagement entity, org.seasar.doma.jdbc.entity.PreInsertContext<com.example.entity.AttendanceManagement> context) {
        __listener.preInsert(entity, context);
    }

    @Override
    public void preUpdate(com.example.entity.AttendanceManagement entity, org.seasar.doma.jdbc.entity.PreUpdateContext<com.example.entity.AttendanceManagement> context) {
        __listener.preUpdate(entity, context);
    }

    @Override
    public void preDelete(com.example.entity.AttendanceManagement entity, org.seasar.doma.jdbc.entity.PreDeleteContext<com.example.entity.AttendanceManagement> context) {
        __listener.preDelete(entity, context);
    }

    @Override
    public void postInsert(com.example.entity.AttendanceManagement entity, org.seasar.doma.jdbc.entity.PostInsertContext<com.example.entity.AttendanceManagement> context) {
        __listener.postInsert(entity, context);
    }

    @Override
    public void postUpdate(com.example.entity.AttendanceManagement entity, org.seasar.doma.jdbc.entity.PostUpdateContext<com.example.entity.AttendanceManagement> context) {
        __listener.postUpdate(entity, context);
    }

    @Override
    public void postDelete(com.example.entity.AttendanceManagement entity, org.seasar.doma.jdbc.entity.PostDeleteContext<com.example.entity.AttendanceManagement> context) {
        __listener.postDelete(entity, context);
    }

    @Override
    public java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> getEntityPropertyTypes() {
        return __entityPropertyTypes;
    }

    @Override
    public org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?> getEntityPropertyType(String __name) {
        return __entityPropertyTypeMap.get(__name);
    }

    @Override
    public java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<com.example.entity.AttendanceManagement, ?>> getIdPropertyTypes() {
        return __idPropertyTypes;
    }

    @Override
    public org.seasar.doma.jdbc.entity.GeneratedIdPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, ?, ?> getGeneratedIdPropertyType() {
        return null;
    }

    @Override
    public org.seasar.doma.jdbc.entity.VersionPropertyType<java.lang.Object, com.example.entity.AttendanceManagement, ?, ?> getVersionPropertyType() {
        return $version;
    }

    @Override
    public com.example.entity.AttendanceManagement newEntity() {
        return new com.example.entity.AttendanceManagement();
    }

    @Override
    public com.example.entity.AttendanceManagement newEntity(java.util.Map<String, Object> __args) {
        return new com.example.entity.AttendanceManagement();
    }

    @Override
    public Class<com.example.entity.AttendanceManagement> getEntityClass() {
        return com.example.entity.AttendanceManagement.class;
    }

    @Override
    public com.example.entity.AttendanceManagement getOriginalStates(com.example.entity.AttendanceManagement __entity) {
        return null;
    }

    @Override
    public void saveCurrentStates(com.example.entity.AttendanceManagement __entity) {
    }

    /**
     * @return the singleton
     */
    public static _AttendanceManagement getSingletonInternal() {
        return __singleton;
    }

    /**
     * @return the new instance
     */
    public static _AttendanceManagement newInstance() {
        return new _AttendanceManagement();
    }

}
