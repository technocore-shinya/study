package com.example.dao;

/** */
@javax.annotation.Generated(value = { "Doma", "1.38.0" }, date = "2019-04-06T13:04:27.626+0900")
public class AttendanceManagementDaoImpl extends org.seasar.doma.internal.jdbc.dao.AbstractDao implements com.example.dao.AttendanceManagementDao {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("1.38.0");
    }

    private static final java.lang.reflect.Method __method0 = org.seasar.doma.internal.jdbc.dao.AbstractDao.__getDeclaredMethod(com.example.dao.AttendanceManagementDao.class, "insert", com.example.entity.AttendanceManagement.class);

    private static final java.lang.reflect.Method __method1 = org.seasar.doma.internal.jdbc.dao.AbstractDao.__getDeclaredMethod(com.example.dao.AttendanceManagementDao.class, "updateById", com.example.entity.AttendanceManagement.class);

    /** */
    public AttendanceManagementDaoImpl() {
        super(new com.example.config.AppConfig());
    }

    /**
     * @param connection the connection
     */
    public AttendanceManagementDaoImpl(java.sql.Connection connection) {
        super(new com.example.config.AppConfig(), connection);
    }

    /**
     * @param dataSource the dataSource
     */
    public AttendanceManagementDaoImpl(javax.sql.DataSource dataSource) {
        super(new com.example.config.AppConfig(), dataSource);
    }

    /**
     * @param config the configuration
     */
    protected AttendanceManagementDaoImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

    /**
     * @param config the configuration
     * @param connection the connection
     */
    protected AttendanceManagementDaoImpl(org.seasar.doma.jdbc.Config config, java.sql.Connection connection) {
        super(config, connection);
    }

    /**
     * @param config the configuration
     * @param dataSource the dataSource
     */
    protected AttendanceManagementDaoImpl(org.seasar.doma.jdbc.Config config, javax.sql.DataSource dataSource) {
        super(config, dataSource);
    }

    @Override
    public int insert(com.example.entity.AttendanceManagement employee) {
        entering("com.example.dao.AttendanceManagementDaoImpl", "insert", employee);
        try {
            if (employee == null) {
                throw new org.seasar.doma.DomaNullPointerException("employee");
            }
            org.seasar.doma.internal.jdbc.query.SqlFileInsertQuery __query = new org.seasar.doma.internal.jdbc.query.SqlFileInsertQuery();
            __query.setMethod(__method0);
            __query.setConfig(config);
            __query.setSqlFilePath("META-INF/com/example/dao/AttendanceManagementDao/insert.sql");
            __query.addParameter("employee", com.example.entity.AttendanceManagement.class, employee);
            __query.setCallerClassName("com.example.dao.AttendanceManagementDaoImpl");
            __query.setCallerMethodName("insert");
            __query.setQueryTimeout(-1);
            __query.setEntityAndEntityType("employee", employee, com.example.entity._AttendanceManagement.getSingletonInternal());
            __query.prepare();
            org.seasar.doma.internal.jdbc.command.InsertCommand __command = new org.seasar.doma.internal.jdbc.command.InsertCommand(__query);
            int __result = __command.execute();
            __query.complete();
            exiting("com.example.dao.AttendanceManagementDaoImpl", "insert", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("com.example.dao.AttendanceManagementDaoImpl", "insert", __e);
            throw __e;
        }
    }

    @Override
    public int updateById(com.example.entity.AttendanceManagement employee) {
        entering("com.example.dao.AttendanceManagementDaoImpl", "updateById", employee);
        try {
            if (employee == null) {
                throw new org.seasar.doma.DomaNullPointerException("employee");
            }
            org.seasar.doma.internal.jdbc.query.SqlFileUpdateQuery __query = new org.seasar.doma.internal.jdbc.query.SqlFileUpdateQuery();
            __query.setMethod(__method1);
            __query.setConfig(config);
            __query.setSqlFilePath("META-INF/com/example/dao/AttendanceManagementDao/updateById.sql");
            __query.addParameter("employee", com.example.entity.AttendanceManagement.class, employee);
            __query.setCallerClassName("com.example.dao.AttendanceManagementDaoImpl");
            __query.setCallerMethodName("updateById");
            __query.setQueryTimeout(-1);
            __query.setEntityAndEntityType("employee", employee, com.example.entity._AttendanceManagement.getSingletonInternal());
            __query.setVersionIncluded(false);
            __query.setVersionIgnored(false);
            __query.setOptimisticLockExceptionSuppressed(false);
            __query.prepare();
            org.seasar.doma.internal.jdbc.command.UpdateCommand __command = new org.seasar.doma.internal.jdbc.command.UpdateCommand(__query);
            int __result = __command.execute();
            __query.complete();
            exiting("com.example.dao.AttendanceManagementDaoImpl", "updateById", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("com.example.dao.AttendanceManagementDaoImpl", "updateById", __e);
            throw __e;
        }
    }

}
