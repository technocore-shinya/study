package com.example.base;

import java.io.File;

public interface BaseExec1 {
	Boolean execDetails(File[] files);
}
