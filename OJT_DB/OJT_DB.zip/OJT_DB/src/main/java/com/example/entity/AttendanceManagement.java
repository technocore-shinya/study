package com.example.entity;

import java.time.LocalDateTime;
import java.util.Date;

import org.seasar.doma.Entity;
import org.seasar.doma.Version;

@Entity
public class AttendanceManagement {
	public int ID;
	public int employeeID;
	public String workingStartTime;
	public String workingEndTime;
	
	public String regName;
	public String regDate;
	public String updName;
	public String updDate;
	@Version
	public int version;
	
	
	

}
