package com.example.dao;

import org.seasar.doma.Dao;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

import com.example.config.AppConfig;
import com.example.entity.AttendanceManagement;
import com.example.entity.Employee;


@Dao(config = AppConfig.class)
public interface AttendanceManagementDao {
	
	@Insert(sqlFile = true)
    int insert(AttendanceManagement employee);

	
	@Update(sqlFile = true)
    int updateById(AttendanceManagement employee);
	
}
