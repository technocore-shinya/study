package com.example.entity;

import org.seasar.doma.Entity;

@Entity
public class WorkForm {
	
	int ID;
	
	String workFormCode;
	
	String workFormName;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getWorkFormCode() {
		return workFormCode;
	}
	public void setWorkFormCode(String workFormCode) {
		this.workFormCode = workFormCode;
	}
	public String getWorkFormName() {
		return workFormName;
	}
	public void setWorkFormName(String workFormName) {
		this.workFormName = workFormName;
	}

}
