package com.example.entity;

import org.seasar.doma.Entity;
@Entity
public class Employee {
	int ID;
	
	String departmentID;
	
	String name;
	
	int years;
	
	String workFormCode;
	
	public String getWorkFormCode() {
		return workFormCode;
	}
	public void setWorkFormCode(String workFormCode) {
		this.workFormCode = workFormCode;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getDepartmentID() {
		return departmentID;
	}
	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}

}
