package com.example.base;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.orangesignal.csv.CsvConfig;

public interface BaseExec2 {
	void execDetails(List<Map<String, String>> csvLines,String Dir,String fileName, CsvConfig conf) throws  Exception;
}
