package com.example.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.example.base.BaseExec2;
import com.example.dao.AttendanceManagementDao;
import com.example.entity.AttendanceManagement;
import com.orangesignal.csv.CsvConfig;

@Service
public class DBAccessService implements BaseExec2 {
	private static final Logger log = LoggerFactory.getLogger(DBAccessService.class);

	@Autowired
	AttendanceManagementDao dao;


	@Override
	@Transactional
	public void execDetails(List<Map<String, String>> csvLines,String dir,String fileName, CsvConfig conf) throws Exception {

		for (Map<String, String> m : csvLines) {

			AttendanceManagement atManageTable =new AttendanceManagement();

			atManageTable.ID =Integer.parseInt(m.get("従業員ID"));

			if(!(checkDateFormat(m.get("出勤時間"))==null)) 
				continue;
			else
				atManageTable.workingStartTime =m.get("出勤時間");

			if(!(checkDateFormat(m.get("退勤時間"))==null)) 
				continue;
			else
				atManageTable.workingEndTime =m.get("退勤時間");

			if (fileName.equals("update"))
				dao.updateById(atManageTable);
			else if(fileName.equals("insert"))
				dao.insert(atManageTable);
			else
				throw new Exception("ファイル名が異なります");
		}

	}


	private String checkDateFormat(String dt) {
		try {
			if (!StringUtils.isEmpty(dt)) {
				Pattern p = Pattern
						.compile("^\\d{4}/\\d{2}/\\d{2} ([0-1][0-9]|[2][0-3]):[0-5][0-9]:[0-5][0-9]$");
				Matcher match = p.matcher(dt);
				if (!match.find()) {
					log.warn("日付の値が不正です");
					return null;
				}
				DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
				df.setLenient(false);
				String s1 = dt;
				String s2 = df.format(df.parse(s1));
				if (!s1.equals(s2)) {
					throw new Exception("日付はカレンダー上発生しません");
				}
				return dt;
			} else {
				log.warn("日付の値が不正です");
				return null;
			}
		} catch (Exception e) {
			log.warn("日付の値が不正です");
			return null;
		}
	}
}
