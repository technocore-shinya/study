package com.example.entity;

import org.seasar.doma.Entity;

@Entity
public class Department {
	int ID;
	String DepartmentName;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getDepartmentName() {
		return DepartmentName;
	}
	public void setDepartmentName(String departmentName) {
		DepartmentName = departmentName;
	}

}
